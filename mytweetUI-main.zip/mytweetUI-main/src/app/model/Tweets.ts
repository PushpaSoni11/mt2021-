export class Tweets{
    constructor(public email_id:string, public tweet: string, public recordTimestamp: string){};
}