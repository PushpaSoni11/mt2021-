export class User{
    constructor(public email_id:string, public first_name:string,public last_name : string,public gender : string,public birth_date : string, public password_key :string){};
}