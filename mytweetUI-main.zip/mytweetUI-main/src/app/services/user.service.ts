import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../model/User';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private  userList : User[] = [
    new User( "devika@gmail.com", "devika",  "Walimbee", "Female", "12-04-1997", "shantu412"),
    new User( "jack@gmail.com", "jack",  " ", "Male", "12-04-1997", "jack123")
  ];

  getUser(userEmail: string){
    return this.userList.find(user => user.email_id === userEmail);
  };

  createUser(userEmail: string, firstname: string, lastname: string, gender: string, birthdate: string, passwordKey: string){
    this.userList.push(new User(userEmail, firstname, lastname, gender, birthdate, passwordKey));
  }

  updateUser(user: User){
    const userToUpdate = this.userList.find(userIterator => userIterator.email_id === user.email_id);
    if(userToUpdate !== null){
      userToUpdate.last_name = user.last_name;
      userToUpdate.password_key = user.password_key;
    }
  }

  deleteUser(userToDelete: User){
    this.userList.splice(this.userList.indexOf(userToDelete),1);
  }

  viewUser(){
    return this.http.get('http://localhost:8081/users');
  }

  constructor(private http: HttpClient) { }
}
