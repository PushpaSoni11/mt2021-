import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateTweetComponent } from './components/create-tweet/create-tweet.component';
import { CreateUserComponent } from './components/create-user/create-user.component';
import { DeleteUserComponent } from './components/delete-user/delete-user.component';
import { EditUserComponent } from './components/edit-user/edit-user.component';
import { TweetsComponent } from './components/tweets/tweets.component';
import { UsersComponent } from './components/users/users.component';


const routes: Routes = [
  {path: 'view', component: UsersComponent},
  {path: 'create', component: CreateUserComponent},
  {path: 'edit', component: EditUserComponent},
  {path: 'delete', component: DeleteUserComponent},
  {path: 'viewTweets', component: TweetsComponent},
  {path: 'postTweet', component: CreateTweetComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 
  
}
