import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/model/User';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
  editingUser: User;
  toSearchUserEmail:string;

  constructor(private userService: UserService) { }

  ngOnInit(): void {
  }

  searchUser(){
    if(this.toSearchUserEmail.length>0){
      this.editingUser = this.userService.getUser(this.toSearchUserEmail);
    }
  }

  saveUser(){
    this.userService.updateUser(this.editingUser);
  }
}
