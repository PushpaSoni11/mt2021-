import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/model/User';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  viewingUser: User;
  toSearchUserEmail: string;

  constructor(private userService: UserService) { }

  ngOnInit(): void {
    
  }

  view(){
    this.userService.viewUser().subscribe(
      response => this.handleResponse(response)
    );
    console.log("result  ");
  }

  searchUser(){
    if(this.toSearchUserEmail.length>0){
      this.viewingUser = this.userService.getUser(this.toSearchUserEmail);
    }
  }

  handleResponse(response){
    console.log(response);
  }

}
