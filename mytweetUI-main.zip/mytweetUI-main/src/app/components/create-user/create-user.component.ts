import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit {

  UserEmailId: string;
  UserFirstName: string;
  UserLastName: string;
  UserGender: string;
  UserBirthDate: string;
  UserPasswordKey: string;

  constructor(private userService: UserService) { }

  ngOnInit(): void {
  }

  saveUser(){
    if(this.validateField()){
      this.userService.createUser(this.UserEmailId, this.UserFirstName, this.UserLastName, this.UserGender, this.UserBirthDate, this.UserPasswordKey);
    }
  }

  private validateField():boolean{
    return (this.UserEmailId.length > 0 && this.UserFirstName.length>0 && this.UserGender.length > 0 && this.UserPasswordKey.length > 0);
  }
}
