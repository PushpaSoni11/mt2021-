import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-tweet',
  templateUrl: './create-tweet.component.html',
  styleUrls: ['./create-tweet.component.css']
})
export class CreateTweetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  saveTweet(){
    console.log("in save");
  }
}
