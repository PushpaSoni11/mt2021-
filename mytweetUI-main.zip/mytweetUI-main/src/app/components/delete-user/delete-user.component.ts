import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/model/User';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-delete-user',
  templateUrl: './delete-user.component.html',
  styleUrls: ['./delete-user.component.css']
})
export class DeleteUserComponent implements OnInit {

  deletingUser: User;
  toSearchUserEmail: string;

  constructor(private userService : UserService) { }

  ngOnInit(): void {
  }

  searchUser(){
    if(this.toSearchUserEmail.length>0){
      this.deletingUser = this.userService.getUser(this.toSearchUserEmail);
    }
  }

  deleteUser(){
    this.userService.deleteUser(this.deletingUser);
  }

}
